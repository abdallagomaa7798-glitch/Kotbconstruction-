# Kotb Construction — Upload Guide

هذه الحزمة تحتوي على ملفات المصدر الخاصة بموقع Kotb Construction. ارفع مجلد المشروع إلى مستودع GitHub خاص، ثم اربطه من Vercel عبر **Add New Project → Import Git Repository**.

## قبل النشر

لا ترفع أي ملف `.env` أو مفاتيح سرية إلى GitHub. أضف القيم داخل **Vercel → Project Settings → Environment Variables**، ثم أعد النشر.

المتغيرات المطلوبة حسب الخدمات المستخدمة:

```text
DATABASE_URL
JWT_SECRET
BUILT_IN_FORGE_API_URL
BUILT_IN_FORGE_API_KEY
VITE_APP_ID
OAUTH_SERVER_URL
VITE_OAUTH_PORTAL_URL
OWNER_OPEN_ID
OWNER_NAME
```

## إعدادات البناء

- Framework Preset: Vite أو Other
- Install Command: `pnpm install`
- Build Command: `pnpm build`
- Production Output Directory: `dist/public`

## ملاحظة مهمة

المشروع يستخدم Vite للواجهة وExpress/tRPC للخادم. قبل استخدام وظائف الخادم مثل تسجيل الدخول، قاعدة البيانات، مساعد قطب وتوليد الصور على Vercel، يجب التأكد من إعداد Express كـ Vercel Function وإضافة متغيرات البيئة المطلوبة. لا تضع مفاتيح API داخل ملفات الواجهة أو داخل GitHub.

## ربط الدومين

بعد نجاح النشر افتح:

`Project → Settings → Domains → Add Domain`

أضف الدومين الأساسي ونسخة `www`، ثم انسخ سجلات DNS التي يعرضها Vercel إلى شركة حجز الدومين. لا تحذف سجلات البريد `MX` أو `SPF` أو `DKIM`.
